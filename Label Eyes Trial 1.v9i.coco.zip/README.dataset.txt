# Label Eyes Trial 1 > 2023-01-31 9:41pm
https://universe.roboflow.com/new-workspace-lyioh/label-eyes-trial-1

Provided by a Roboflow user
License: CC BY 4.0

- [Y] Import 1079 images (full set) from Google Drive 
- [ ] Label right and left eye as one class and name as "eyes"
- [ ] Remove the images with no anatomy and artifacts 
- [ ] Show Sam 
- [ ] Invite Shuhadah to inter-rate 
- [ ] Export labelling and measure IoU 