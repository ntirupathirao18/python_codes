# bone fracture > release
https://universe.roboflow.com/object-detection/bone-fracture-7fylg

Provided by Roboflow
License: CC BY 4.0

